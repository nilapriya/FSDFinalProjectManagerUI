export class StaticTaskService {

    editTask: any = {};
}