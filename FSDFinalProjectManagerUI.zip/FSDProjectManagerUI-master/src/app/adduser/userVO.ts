export class UserVO {
    public employeeId: string;
    public firstName: string;
    public lastName: string;
    public status: string;
}