export class ParentTask {
        public parentTaskId: number;
        public parentTaskName: string;
        public projectId: number;
    }